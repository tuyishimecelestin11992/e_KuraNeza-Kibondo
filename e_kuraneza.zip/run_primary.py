from analysis import *
import pickle
gss=GroupShuffleSplit(1,test_size=0.2,random_state=SEED)
tr,te=next(gss.split(X,y,groups))
assert len(set(groups[tr])&set(groups[te]))==0
out['split']={'train_n':len(tr),'test_n':len(te),'train_pos':int(y[tr].sum()),'test_pos':int(y[te].sum()),'train_prev':float(y[tr].mean()),'test_prev':float(y[te].mean()),'blocks_train':int(len(set(groups[tr]))),'blocks_test':int(len(set(groups[te]))),'overlap':0}
res,(Xte,yte)=run_split(tr,te,'primary')
best=max(['Logistic regression','Random forest','SVM'],key=lambda k:res[k]['m']['auc'])
out['best']=best
for k,v in res.items():
    thr=v['thr'] if v['thr'] is not None else 1.0
    ci=boot(yte,v['p'],thr,1000) if k!='Majority-class baseline' else None
    v['ci']=ci
pickle.dump({'res':res,'tr':tr,'te':te,'out':out},open('primary.pkl','wb'))
print(out['split'],best)
