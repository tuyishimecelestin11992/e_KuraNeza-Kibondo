import pandas as pd, numpy as np
REF = pd.Timestamp('2025-12-15')   # reference date for age (not in file; reproduces earlier age distribution)
PRED_CAT = ['sex_new','amashuri_mama_w_umwana_yiz','umwana_afite_ababyeyi','sick','mmf','fbf','vup',
            'ese_haba_hari_amakimbirane','icyo_umurera_akora','water','handwash','toilet']
def load():
    raw = pd.read_csv('/mnt/user-data/uploads/Stunting_Updated.csv')
    raw['row'] = np.arange(len(raw))
    flow = {'start': len(raw)}
    df = raw[raw.HAZ.notna()].copy()
    flow['valid_haz'] = len(df)
    flow['missing_haz'] = flow['start'] - len(df)
    df['dob'] = pd.to_datetime(df.child_dob, dayfirst=True, errors='coerce')
    df['age_m'] = (REF - df.dob).dt.days / 30.4375
    bad = df.age_m.isna() | (df.age_m < 0) | (df.age_m >= 60)
    flow['bad_age'] = int(bad.sum())
    df = df[~bad].copy()
    flow['after_age'] = len(df)
    cols = [c for c in raw.columns if c not in ('row',)]
    dup = df.duplicated(subset=cols, keep='first')
    flow['exact_dups'] = int(dup.sum())
    full = df.copy()
    df = df[~dup].copy()
    flow['final'] = len(df)
    df['y'] = (df.HAZ == 'Stunted').astype(int)
    full['y'] = (full.HAZ == 'Stunted').astype(int)
    return raw, df, full, flow
