import sys, json, time, warnings; sys.path.insert(0,'/home/claude'); warnings.filterwarnings('ignore')
from prep import *
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.dummy import DummyClassifier
from sklearn.model_selection import GroupShuffleSplit, StratifiedKFold, RandomizedSearchCV, train_test_split, cross_val_predict
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, roc_curve
from sklearn.inspection import permutation_importance
from scipy.stats import chi2_contingency
SEED=42; rng=np.random.default_rng(SEED)
raw, df, full, flow = load()
df=df.reset_index(drop=True)
CAT=PRED_CAT; NUM=['age_m']
X=df[CAT+NUM]; y=df.y.values
groups=(df.row.values//200)           # pseudo-clusters: 200 consecutive file rows
out={'flow':flow,'n':len(df),'stunted':int(y.sum()),'prev':float(y.mean())}

def prep(cat,num):
    return ColumnTransformer([('c',Pipeline([('i',SimpleImputer(strategy='most_frequent')),('o',OneHotEncoder(handle_unknown='ignore'))]),cat),
                              ('n',Pipeline([('i',SimpleImputer(strategy='median')),('s',StandardScaler())]),num)])
def pipe(model,cat=CAT,num=NUM): return Pipeline([('p',prep(cat,num)),('m',model)])
def score(m,X): 
    return m.predict_proba(X)[:,1] if hasattr(m,'predict_proba') else m.decision_function(X)
def metrics(yt,p,thr):
    pred=(p>=thr).astype(int); tp=((pred==1)&(yt==1)).sum(); tn=((pred==0)&(yt==0)).sum(); fp=((pred==1)&(yt==0)).sum(); fn=((pred==0)&(yt==1)).sum()
    sens=tp/(tp+fn); spec=tn/(tn+fp); ppv=tp/(tp+fp) if tp+fp else np.nan; npv=tn/(tn+fn) if tn+fn else np.nan
    return dict(auc=roc_auc_score(yt,p),pr=average_precision_score(yt,p),sens=sens,spec=spec,ppv=ppv,npv=npv,bal=(sens+spec)/2,tp=int(tp),fp=int(fp),tn=int(tn),fn=int(fn))
def boot(yt,p,thr,B=1000):
    n=len(yt); res=[]
    for b in range(B):
        i=rng.integers(0,n,n)
        if yt[i].min()==yt[i].max(): continue
        m=metrics(yt[i],p[i],thr); res.append([m[k] for k in ['auc','pr','sens','spec','ppv','npv','bal']])
    r=np.array(res); return np.nanpercentile(r,[2.5,97.5],axis=0)
def youden(yt,p):
    f,t,th=roc_curve(yt,p); return th[np.argmax(t-f)]

def run_split(tr,te,tag,models=('Logistic regression','Random forest','SVM'),cat=CAT,num=NUM,tune=True,svm_sub=12000,B=1000,verbose=True):
    Xtr,Xte,ytr,yte=df.loc[tr,cat+num],df.loc[te,cat+num],y[tr],y[te]
    cv=StratifiedKFold(3,shuffle=True,random_state=SEED)
    res={}
    base=DummyClassifier(strategy='most_frequent').fit(Xtr,ytr)
    res['Majority-class baseline']=dict(m=metrics(yte,np.full(len(yte),ytr.mean()),1.0), thr=None, params='none', p=np.full(len(yte),ytr.mean()))
    specs={
     'Logistic regression':(LogisticRegression(max_iter=2000,solver='lbfgs'),{'m__C':[0.01,0.1,1,10],'m__class_weight':[None,'balanced']}),
     'Random forest':(RandomForestClassifier(random_state=SEED,n_jobs=1),{'m__n_estimators':[150,300],'m__max_depth':[6,10,16,None],'m__min_samples_leaf':[5,20,50],'m__class_weight':[None,'balanced']}),
     'SVM':(SVC(kernel='rbf',probability=False),{'m__C':[0.1,1,10],'m__gamma':['scale',0.01],'m__class_weight':[None,'balanced']}),
    }
    for name in models:
        t0=time.time(); est,grid=specs[name]; pp=pipe(est,cat,num)
        if tune:
            # tune on stratified subsample for speed in SVM / RF, 5-fold CV inside training only
            if name=='SVM':
                idx=np.random.default_rng(SEED).choice(len(Xtr),svm_sub,replace=False)
                s=RandomizedSearchCV(pp,grid,n_iter=6,cv=cv,scoring='roc_auc',random_state=SEED,n_jobs=1).fit(Xtr.iloc[idx],ytr[idx])
                best=s.best_params_; pp.set_params(**best)
                # final SVM fit on a larger training subsample (memory/time)
                idx2=np.random.default_rng(SEED+1).choice(len(Xtr),min(len(Xtr),30000),replace=False)
                pp.fit(Xtr.iloc[idx2],ytr[idx2])
                trscore=cross_val_predict(pipe(SVC(kernel='rbf').set_params(**{k.split('__')[1]:v for k,v in best.items()}),cat,num),Xtr.iloc[idx],ytr[idx],cv=cv,method='decision_function')
                thr=youden(ytr[idx],trscore)
            else:
                nit=5 if name=='Random forest' else 6
                s=RandomizedSearchCV(pp,grid,n_iter=nit,cv=cv,scoring='roc_auc',random_state=SEED,n_jobs=1).fit(Xtr,ytr)
                best=s.best_params_; pp=s.best_estimator_
                trscore=cross_val_predict(pp,Xtr,ytr,cv=cv,method='predict_proba')[:,1]
                thr=youden(ytr,trscore)
        p=score(pp,Xte)
        res[name]=dict(m=metrics(yte,p,thr),thr=float(thr),params={k.replace('m__',''):(v if v is not None else 'None') for k,v in best.items()},p=p,model=pp)
        if verbose: print(tag,name,{k:round(v,3) for k,v in res[name]['m'].items() if k in('auc','pr','sens','spec','bal')},res[name]['params'],round(time.time()-t0),'s',flush=True)
    return res,(Xte,yte)
