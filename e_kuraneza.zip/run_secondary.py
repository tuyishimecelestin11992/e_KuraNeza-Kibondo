from analysis import *
import pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from sklearn.calibration import calibration_curve
P=pickle.load(open('primary.pkl','rb')); res=P['res']; tr=P['tr']; te=P['te']; out=P['out']
S={}
yte=y[te]; Xte=df.loc[te,CAT+NUM]
best='Random forest'; bp=res[best]['model']; pbest=res[best]['p']; thr=res[best]['thr']
# ---- Table 3 values
T3={}
for k,v in res.items():
    m=v['m']; ci=v['ci']
    T3[k]={**m,'thr':v['thr'],'params':v['params'],'ci':(ci.tolist() if ci is not None else None),
           'brier':float(brier_score_loss(yte,v['p'])) if k in('Logistic regression','Random forest','Majority-class baseline') else None}
S['T3']=T3
# paired bootstrap AUC differences
def paired(pa,pb,B=1000):
    d=[]; n=len(yte)
    for b in range(B):
        i=rng.integers(0,n,n)
        if yte[i].min()==yte[i].max(): continue
        d.append(roc_auc_score(yte[i],pa[i])-roc_auc_score(yte[i],pb[i]))
    return float(np.mean(d)),np.percentile(d,[2.5,97.5]).tolist()
S['paired']={'RF-LR':paired(res['Random forest']['p'],res['Logistic regression']['p']),
             'RF-SVM':paired(res['Random forest']['p'],res['SVM']['p']),
             'LR-SVM':paired(res['Logistic regression']['p'],res['SVM']['p'])}
# ---- calibration
def calib(p):
    lp=np.log(np.clip(p,1e-6,1-1e-6)/(1-np.clip(p,1e-6,1-1e-6)))
    m=LogisticRegression(C=1e6,max_iter=1000).fit(lp.reshape(-1,1),yte)
    return float(m.intercept_[0]),float(m.coef_[0][0])
S['calib']={k:calib(res[k]['p']) for k in ('Logistic regression','Random forest')}
fig,ax=plt.subplots(1,2,figsize=(10,4.2))
for k,c in (('Logistic regression','tab:blue'),('Random forest','tab:red')):
    fr,mp=calibration_curve(yte,res[k]['p'],n_bins=10,strategy='quantile'); ax[0].plot(mp,fr,'o-',label=k,color=c)
ax[0].plot([0,1],[0,1],'k--',lw=1); ax[0].set_xlabel('Mean predicted probability'); ax[0].set_ylabel('Observed proportion stunted'); ax[0].legend(); ax[0].set_title('Calibration (test set)')
for k,c in (('Logistic regression','tab:blue'),('Random forest','tab:red'),('SVM','tab:green')):
    f,t,_=roc_curve(yte,res[k]['p']); ax[1].plot(f,t,label=f"{k} (AUC {res[k]['m']['auc']:.2f})",color=c)
ax[1].plot([0,1],[0,1],'k--',lw=1); ax[1].set_xlabel('1 - specificity'); ax[1].set_ylabel('Sensitivity'); ax[1].legend(loc='lower right'); ax[1].set_title('ROC curves (test set)')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/Figure_calibration_ROC.png',dpi=200); plt.close()
# ---- permutation importance (original variables), RF, test set
pi=permutation_importance(bp,Xte,yte,scoring='roc_auc',n_repeats=10,random_state=SEED,n_jobs=1)
imp=pd.DataFrame({'var':CAT+NUM,'mean':pi.importances_mean,'sd':pi.importances_std}).sort_values('mean',ascending=False)
S['imp']=imp.values.tolist()
lab={'age_m':'Child age','sex_new':'Child sex','amashuri_mama_w_umwana_yiz':"Mother's education",'umwana_afite_ababyeyi':'Living with parents','sick':'Illness (2 weeks)','mmf':'Min. meal frequency','fbf':'Fortified blended food','vup':'VUP enrolment','ese_haba_hari_amakimbirane':'Household conflict','icyo_umurera_akora':"Caregiver occupation",'water':'Improved water','handwash':'Handwashing facility','toilet':'Improved toilet'}
fig,ax=plt.subplots(figsize=(6.5,4.2)); im=imp.iloc[::-1]
ax.barh([lab[v] for v in im['var']],im['mean'],xerr=im['sd'],color='tab:gray'); ax.set_xlabel('Drop in test AUC when variable is shuffled (mean, SD of 10 repeats)'); ax.set_title('Permutation importance, random forest')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/Figure_permutation_importance.png',dpi=200); plt.close()
# ---- subgroup performance (RF at fixed thr)
sub={}
te_df=df.loc[te].copy(); te_df['p']=pbest
te_df['agegrp']=np.where(te_df.age_m<24,'0-23 months','24-59 months')
for col,name in (('sex_new','Sex'),('agegrp','Age group'),('amashuri_mama_w_umwana_yiz',"Mother's education")):
    for g,d in te_df.groupby(col):
        if d.y.nunique()<2 or len(d)<100: continue
        m=metrics(d.y.values,d.p.values,thr); sub[f'{name}: {g}']=dict(n=len(d),prev=float(d.y.mean()),auc=m['auc'],sens=m['sens'],spec=m['spec'])
S['sub']=sub
# ---- helper for fixed-param refits
def refit(dfx,tr_i,te_i,cat,num,kind,rf_params=res[best]['params'],lr_params=res['Logistic regression']['params']):
    Xa=dfx.loc[tr_i,cat+num]; Xb=dfx.loc[te_i,cat+num]; ya=dfx.y.loc[tr_i].values; yb=dfx.y.loc[te_i].values
    if kind=='RF':
        rp=dict(rf_params); cw=None if rp['class_weight']=='None' else rp['class_weight']
        mdl=RandomForestClassifier(n_estimators=rp['n_estimators'],max_depth=rp['max_depth'] if rp['max_depth']!='None' else None,min_samples_leaf=rp['min_samples_leaf'],class_weight=cw,random_state=SEED,n_jobs=1)
    else:
        lp=dict(lr_params); mdl=LogisticRegression(C=lp['C'],class_weight=None if lp['class_weight']=='None' else lp['class_weight'],max_iter=2000)
    pp=pipe(mdl,cat,num).fit(Xa,ya); p=pp.predict_proba(Xb)[:,1]
    tp=cross_val_predict(pipe(mdl,cat,num),Xa,ya,cv=StratifiedKFold(3,shuffle=True,random_state=SEED),method='predict_proba')[:,1]
    m=metrics(yb,p,youden(ya,tp)); return {k:float(m[k]) for k in ('auc','pr','sens','spec','bal')}
SENS={}
for tag,cat,num in (('Primary (all 13 predictors)',CAT,NUM),('Without age',CAT,[]),('Without fortified blended food',[c for c in CAT if c!='fbf'],NUM),('Without age and fortified blended food',[c for c in CAT if c!='fbf'],[])):
    SENS[tag]={k:refit(df,tr,te,cat,num,k) for k in ('LR','RF')}; print(tag,SENS[tag],flush=True)
# anthropometric leakage demonstration
dfa=df.copy()
dfa['height_c']=dfa.height.where((dfa.height>=40)&(dfa.height<=130)); dfa['weight_c']=dfa.weight.where((dfa.weight>=2)&(dfa.weight<=30)); dfa['muac_c']=dfa.muac.where((dfa.muac>=80)&(dfa.muac<=250))
SENS['Adding height, weight and MUAC (leakage demonstration)']={k:refit(dfa,tr,te,CAT,NUM+['height_c','weight_c','muac_c'],k) for k in ('LR','RF')}
SENS['Height and age only']={'RF':refit(dfa,tr,te,['sex_new'],['age_m','height_c'],'RF'),'LR':refit(dfa,tr,te,['sex_new'],['age_m','height_c'],'LR')}
print({k:v for k,v in SENS.items() if 'Adding' in k or 'Height' in k},flush=True)
# alternative splits
# (a) random stratified split on de-duplicated data
tr_r,te_r=train_test_split(np.arange(len(df)),test_size=0.2,stratify=y,random_state=SEED)
SENS['Random split, de-duplicated']={k:refit(df,tr_r,te_r,CAT,NUM,k) for k in ('LR','RF')}
# (b) random split with exact duplicates kept
fl=full.reset_index(drop=True)
tr_f,te_f=train_test_split(np.arange(len(fl)),test_size=0.2,stratify=fl.y.values,random_state=SEED)
SENS['Random split, duplicates kept']={k:refit(fl,tr_f,te_f,CAT,NUM,k) for k in ('LR','RF')}
# (c) last 20% of file order as test
order=df.row.values.argsort(); cut=int(0.8*len(df)); tr_o,te_o=order[:cut],order[cut:]
SENS['Last 20% of file order as test']={k:refit(df,tr_o,te_o,CAT,NUM,k) for k in ('LR','RF')}
S['SENS']=SENS
for k,v in SENS.items(): print(k,{a:round(b['auc'],3) for a,b in v.items()})
# ---- descriptive table on final sample
rows=[]
def chi(col,order=None):
    ct=pd.crosstab(df[col],df.y); chi2,p,_,_=chi2_contingency(ct); return p
labels={'sex_new':'Sex','amashuri_mama_w_umwana_yiz':"Mother's education",'umwana_afite_ababyeyi':'Child has parents (lives with)','sick':'Illness, previous 2 weeks','mmf':'Minimum meal frequency met','fbf':'Fortified blended food','vup':'VUP enrolment','ese_haba_hari_amakimbirane':'Household conflict','icyo_umurera_akora':"Caregiver occupation",'water':'Improved water source','handwash':'Handwashing facility','toilet':'Improved toilet'}
d2=df.copy(); d2['agegrp']=np.where(d2.age_m<24,'0-23 months','24-59 months')
for col,name in [('sex_new','Sex'),('agegrp','Age group')]+[(c,labels[c]) for c in CAT if c!='sex_new']:
    dd=d2.dropna(subset=[col]); ct=pd.crosstab(dd[col],dd.y); p=chi2_contingency(ct)[1]
    for cat_,r in ct.iterrows():
        rows.append([name,cat_,int(r.sum()),round(100*r.sum()/len(dd),1),int(r[1]),round(100*r[1]/r.sum(),1),p])
S['desc']=rows
S['age']={'mean':float(df.age_m.mean()),'sd':float(df.age_m.std()),'u24':int((df.age_m<24).sum())}
S['miss']={c:int(df[c].isna().sum()) for c in CAT}
S['anyMiss']=int(df[CAT].isna().any(axis=1).sum())
anth={}
for c in ('height','weight','muac'):
    anth[c]=dict(n=int(df[c].notna().sum()),mean=float(dfa[c+'_c'].mean()),sd=float(dfa[c+'_c'].std()),n_clean=int(dfa[c+'_c'].notna().sum()))
S['anth']=anth
S['out']=out
json.dump(S,open('results.json','w'),default=float,indent=1)
print('done')
